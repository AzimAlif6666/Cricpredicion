import os
import sys
import argparse
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import joblib
from datetime import datetime
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import (
    accuracy_score, classification_report, f1_score
)

# === LOGGING ===
os.makedirs("logs", exist_ok=True)
log_file = f"logs/model_log.txt"
sys.stdout = open(log_file, 'w')
print(f"[LOG] Script started at {datetime.now().isoformat()}")

# === ARGUMENT PARSING ===
parser = argparse.ArgumentParser(description="Train and predict cricket match winners.")
parser.add_argument(
    "--predict-file", type=str, default=None,
    help="Optional: path to a new CSV file to predict on (must have same structure)"
)
args = parser.parse_args()

# === CONFIGURATION ===
# Default training data (change this to train on a different dataset)
DATA_CSV_PATH = "data/matches_weather.csv"
MODEL_OUT_PATH = "data/match_winner_model.pkl"
PLOT_OUT_PATH = "data/feature_importance.png"
PREDICTIONS_CSV_PATH = "data/predictions.csv"

# === LOAD TRAINING DATA ===
df = pd.read_csv(DATA_CSV_PATH)
df = df.dropna(subset=["winner", "team1", "team2", "toss_winner", "toss_decision", "temp_max", "temp_min"])

# Encode categorical fields
label_encoders = {}
for col in ["team1", "team2", "toss_winner", "toss_decision", "venue"]:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col].astype(str))
    label_encoders[col] = le

# Encode target labels
target_le = LabelEncoder()
df["winner_encoded"] = target_le.fit_transform(df["winner"].astype(str))

features = ["team1", "team2", "toss_winner", "toss_decision", "venue", "temp_max", "temp_min", "precipitation"]
X = df[features]
y = df["winner_encoded"]

# === TRAIN MODEL ===
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X, y)
joblib.dump(model, MODEL_OUT_PATH)
print(f"\n✅ Model trained and saved to: {MODEL_OUT_PATH}")

# === EVALUATION ON TRAIN DATA ===
y_pred = model.predict(X)
accuracy = accuracy_score(y, y_pred)
print(f"\n✅ Training Accuracy: {accuracy:.4f}")

print("\n📊 Classification Report:")
print(classification_report(
    y, y_pred,
    labels=np.unique(y),
    target_names=target_le.inverse_transform(np.unique(y)),
    zero_division=0
))

print(f"Macro F1 Score: {f1_score(y, y_pred, average='macro', zero_division=0):.4f}")
print(f"Micro F1 Score: {f1_score(y, y_pred, average='micro', zero_division=0):.4f}")

# === FEATURE IMPORTANCE PLOT ===
importances = model.feature_importances_
indices = np.argsort(importances)[::-1]
plt.figure(figsize=(10, 6))
plt.title("Feature Importances")
plt.bar(range(X.shape[1]), importances[indices], align="center")
plt.xticks(range(X.shape[1]), [features[i] for i in indices], rotation=45)
plt.tight_layout()
plt.savefig(PLOT_OUT_PATH)
print(f"\n📈 Feature importance plot saved to: {PLOT_OUT_PATH}")

# === CHOOSE DATA TO PREDICT ON ===
if args.predict_file:
    print(f"\n🔍 Predicting on external file: {args.predict_file}")
    pred_df = pd.read_csv(args.predict_file)
else:
    print(f"\n🔍 Predicting on same training file: {DATA_CSV_PATH}")
    pred_df = pd.read_csv(DATA_CSV_PATH)

# Preprocess prediction data
for col in ["team1", "team2", "toss_winner", "toss_decision", "venue"]:
    if col in pred_df.columns:
        le = label_encoders[col]
        pred_df[col] = pred_df[col].astype(str).apply(lambda x: x if x in le.classes_ else "unknown")
        if "unknown" not in le.classes_:
            le.classes_ = np.append(le.classes_, "unknown")
        pred_df[col] = le.transform(pred_df[col])

X_pred = pred_df[features]
proba = model.predict_proba(X_pred)
predicted_indices = model.predict(X_pred)
predicted_labels = target_le.inverse_transform(predicted_indices)

# Compute confidence
confidence = np.max(proba, axis=1)

# Top 3 predictions
top3_teams, top3_probs = [], []
for i in range(len(proba)):
    idx = np.argsort(proba[i])[-3:][::-1]
    top3_teams.append(target_le.inverse_transform(idx))
    top3_probs.append(proba[i][idx])

top1, top2, top3 = zip(*top3_teams)
prob1, prob2, prob3 = zip(*top3_probs)

# Assemble prediction output
output_df = pd.DataFrame({
    "match_id": pred_df.get("match_id", range(len(pred_df))),
    "actual_winner": pred_df.get("winner", "unknown"),
    "predicted_winner": predicted_labels,
    "confidence": confidence,
    "top1": top1,
    "top1_prob": prob1,
    "top2": top2,
    "top2_prob": prob2,
    "top3": top3,
    "top3_prob": prob3
})

output_df.to_csv(PREDICTIONS_CSV_PATH, index=False)
print(f"\n📄 Predictions saved to: {PREDICTIONS_CSV_PATH}")

# === FINAL OUTPUT SUMMARY ===
print("\n🎯 All tasks completed successfully.\n")
print("📂 Output Summary:")
print(f"   🔹 Trained model saved to       →  {MODEL_OUT_PATH}")
print(f"   🔹 Feature importance plot      →  {PLOT_OUT_PATH}")
print(f"   🔹 Predictions CSV              →  {PREDICTIONS_CSV_PATH}")
print(f"   🔹 Full log written to          →  {log_file}")
print("\n✅ You can now open the predictions CSV or log to inspect results.\n")

