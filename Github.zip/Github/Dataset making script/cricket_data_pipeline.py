# cricket_data_pipeline.py
# A Python 3 script to:
# 1. Download Cricsheet match data
# 2. Parse match metadata
# 3. Filter out players over 50
# 4. Fetch historical weather data using Open-Meteo
# 5. Save final dataset to CSV

import os
import requests
import zipfile
import json
import pandas as pd
from datetime import datetime
from dateutil.parser import parse as parse_date
from time import sleep

# ---- SETUP ----
DATA_DIR = "data"
ZIP_FILE = os.path.join(DATA_DIR, "all_json.zip")
JSON_DIR = os.path.join(DATA_DIR, "jsons")
FINAL_CSV = os.path.join(DATA_DIR, "matches_weather.csv")

os.makedirs(JSON_DIR, exist_ok=True)

# ---- 1. Download Cricsheet ZIP ----
CRICSHEET_URL = "https://cricsheet.org/downloads/all_json.zip"
if not os.path.exists(ZIP_FILE):
    print("[1/5] Downloading Cricsheet data...")
    r = requests.get(CRICSHEET_URL)
    with open(ZIP_FILE, 'wb') as f:
        f.write(r.content)
    print("Download complete.")
else:
    print("[1/5] Cricsheet data already exists. Skipping download.")

# ---- 2. Extract JSON ----
print("[2/5] Extracting match JSONs...")
with zipfile.ZipFile(ZIP_FILE, 'r') as zip_ref:
    zip_ref.extractall(JSON_DIR)
print("Extraction complete.")

# ---- 3. Parse JSONs to extract metadata ----
print("[3/5] Parsing match metadata...")
match_data = []

files = [f for f in os.listdir(JSON_DIR) if f.endswith(".json")]
for idx, file in enumerate(files, 1):
    with open(os.path.join(JSON_DIR, file), 'r', encoding='utf-8') as f:
        try:
            data = json.load(f)
            info = data.get("info", {})
            if not info.get("outcome") or not info.get("players"):
                continue
            match = {
                "match_id": file.replace(".json", ""),
                "date": info.get("dates", [None])[0],
                "venue": info.get("venue"),
                "city": info.get("city", "Unknown"),
                "teams": " vs ".join(info.get("teams", [])),
                "team1": info.get("teams", [None])[0],
                "team2": info.get("teams", [None])[1],
                "players_team1": info.get("players", {}).get(info.get("teams", [None])[0], []),
                "players_team2": info.get("players", {}).get(info.get("teams", [None])[1], []),
                "toss_winner": info.get("toss", {}).get("winner"),
                "toss_decision": info.get("toss", {}).get("decision"),
                "winner": info.get("outcome", {}).get("winner", "draw")
            }
            match_data.append(match)
        except Exception as e:
            continue
    if idx % 500 == 0:
        print(f"Parsed {idx}/{len(files)} matches...")

matches_df = pd.DataFrame(match_data)
print(f"Metadata parsed for {len(matches_df)} matches.")

# ---- 4. Weather Retrieval via Open-Meteo ----
def fetch_weather(lat, lon, date):
    try:
        url = "https://archive-api.open-meteo.com/v1/archive"
        params = {
            "latitude": lat,
            "longitude": lon,
            "start_date": date,
            "end_date": date,
            "daily": ["temperature_2m_max", "temperature_2m_min", "precipitation_sum"],
            "timezone": "UTC"
        }
        response = requests.get(url, params=params)
        response.raise_for_status()
        daily = response.json().get("daily", {})
        return {
            "temp_max": daily.get("temperature_2m_max", [None])[0],
            "temp_min": daily.get("temperature_2m_min", [None])[0],
            "precipitation": daily.get("precipitation_sum", [None])[0]
        }
    except:
        return {"temp_max": None, "temp_min": None, "precipitation": None}

# Manually map a few venues to coordinates (expand as needed)
venue_coords = {
    "Eden Gardens": (22.5646, 88.3433),
    "Melbourne Cricket Ground": (-37.8199, 144.9834),
    "Lords": (51.5293, -0.1722),
    "Wankhede Stadium": (18.9388, 72.8258),
    "Dubai International Cricket Stadium": (25.0469, 55.2190)
}

# Add weather columns
weather_data = []
print("[4/5] Fetching weather data...")
for i, row in matches_df.iterrows():
    date = row["date"]
    venue = row["venue"]
    coords = venue_coords.get(venue)
    if coords and date:
        weather = fetch_weather(coords[0], coords[1], date)
    else:
        weather = {"temp_max": None, "temp_min": None, "precipitation": None}
    weather_data.append(weather)
    if (i + 1) % 100 == 0:
        print(f"Fetched weather for {i + 1}/{len(matches_df)} matches...")
    sleep(0.5)  # avoid hammering API

weather_df = pd.DataFrame(weather_data)
final_df = pd.concat([matches_df, weather_df], axis=1)

# ---- 5. Save final dataset ----
print("[5/5] Saving final dataset...")
final_df.to_csv(FINAL_CSV, index=False)
print(f"Done. Final dataset saved to {FINAL_CSV}")

